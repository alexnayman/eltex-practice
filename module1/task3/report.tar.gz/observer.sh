#!/bin/bash

WORK_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$WORK_DIR"

CONF_FILE="observer.conf"
LOG_FILE="observer.log"

if [[ ! -f "$CONF_FILE" ]]; then
    echo "Файл конфигурации $CONF_FILE не найден" >> "$LOG_FILE"
    exit 1
fi

while IFS= read -r task || [[ -n "$task" ]]; do
    [[ -z "$task" || "$task" =~ ^# ]] && continue

    found=0
    for pid_dir in /proc/[0-9]*; do
        if [[ -r "$pid_dir/cmdline" ]]; then
            cmdline=$(tr '\0' ' ' < "$pid_dir/cmdline" 2>/dev/null)
            if echo "$cmdline" | grep -q "$task"; then
                found=1
                break
            fi
        fi
    done

    if [[ $found -eq 0 ]]; then
        echo "$(date '+%Y-%m-%d %H:%M:%S') Перезапуск $task" >> "$LOG_FILE"
        nohup ./"$task" &
    fi
done < "$CONF_FILE"
