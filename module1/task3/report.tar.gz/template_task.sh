#!/bin/bash

SCRIPT_NAME="$(basename "$0")"
WORK_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$WORK_DIR"
LOG_FILE="report_${SCRIPT_NAME}.log"
PIPE="/tmp/run/cuckoo.pid"

if [[ "$SCRIPT_NAME" == "template_task.sh" ]]; then
    echo "я бригадир, сам не работаю"
    echo "$(date '+%Y-%m-%d %H:%M:%S') [$$] я бригадир, сам не работаю" >> "report_${SCRIPT_NAME}.log"
    exit 1
fi

echo "$(date '+%Y-%m-%d %H:%M:%S') [$$] Скрипт запущен" >> "$LOG_FILE"

msg="${SCRIPT_NAME}[$$]: how much time do I have?"

echo "$msg" > "$PIPE"

RESP_FILE="/tmp/run/resp_$$"
timeout=10
count=0
while [[ ! -f "$RESP_FILE" ]]; do
    sleep 0.1
    ((count++))
    if [[ $count -gt $((timeout * 10)) ]]; then
        echo "$(date '+%Y-%m-%d %H:%M:%S') [$$] Ошибка: нет ответа от cuckoo" >> "$LOG_FILE"
        exit 1
    fi
done

n=$(cat "$RESP_FILE")
rm -f "$RESP_FILE"

sleep "$n"

echo "$(date '+%Y-%m-%d %H:%M:%S') [$$] Скрипт завершился, работал $n секунд." >> "$LOG_FILE"
